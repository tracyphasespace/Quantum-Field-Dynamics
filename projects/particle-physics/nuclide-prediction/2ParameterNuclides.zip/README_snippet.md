# Nuclide Law Reproduction (Quick Start)

## 1) Install deps
```bash
python -m venv .venv && source .venv/bin/activate  # or .venv\Scripts\activate on Windows
pip install -r requirements.txt
```

## 2) Prepare data
Provide a CSV with at least these columns:
- `A` : mass number (integer)
- `Z` : proton (charge) number (integer)
Optional:
- `is_stable` : boolean or 0/1
- `half_life_s` : half-life in seconds (float; NaN/blank allowed)

## 3) Run
```bash
python reproduce_nuclide_law.py --csv path/to/NuBase2020_like.csv --outdir out
```

## 4) Outputs
- `out/summary.json` : fit metrics (R², RMSE, c1, c2, bootstrapped SEs), correlations if half-life present
- `out/figure_backbone_Q_vs_A.png`
- `out/figure_residuals_vs_A.png`
- `out/figure_abs_residual_vs_log10_half_life.png` (if half-life provided)
- `out/report.md` : copy-paste-ready summary with embedded figures