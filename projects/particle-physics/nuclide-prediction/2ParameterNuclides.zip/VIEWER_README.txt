Open out\density_ratio_interactive.html in any modern browser.
Controls: drag to pan • mouse wheel to zoom • double-click to reset.
