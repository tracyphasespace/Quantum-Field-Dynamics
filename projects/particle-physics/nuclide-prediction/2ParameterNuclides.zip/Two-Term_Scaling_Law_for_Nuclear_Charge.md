# A Universal Two-Term Scaling Law for Nuclear Charge and Stability Across 5,842 Isotopes
**Author:** Tracy McSheery

> This markdown is a scaffold. After running `reproduce_nuclide_law.py`, copy the three PNGs from `out/` into a `docs/` folder in your repo and update the relative paths below if needed.

## Abstract
[Paste your final abstract here.]

## 1. Introduction
[Paste Introduction.]

## 2. Methods
Briefly: we fit \( Z(A) = c_1 A^{2/3} + c_2 A \) by OLS on all isotopes in NuBase 2020; compute residuals \( \Delta Q = Z - \hat{Z} \); and correlate \( |\Delta Q| \) with \( \log_{10} T_{1/2} \).

## 3. Results

### 3.1 Universal Backbone Fit
![Backbone](docs/figure_backbone_Q_vs_A.png)

### 3.2 Residuals as an Organizing Principle
![Residuals](docs/figure_residuals_vs_A.png)

### 3.3 |ΔQ| vs log10(half-life)
![|ΔQ| vs log10 half-life](docs/figure_abs_residual_vs_log10_half_life.png)

## 4. Discussion
[Paste Discussion.]

## 5. Data and Code Availability
Scripts: `reproduce_nuclide_law.py`, `requirements.txt`  
Figures generated to `out/` by default.