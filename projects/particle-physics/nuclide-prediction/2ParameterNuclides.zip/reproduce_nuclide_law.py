#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
reproduce_nuclide_law.py  — refreshed
Features:
- Fits Z ≈ c1*A^(2/3) + c2*A by OLS (with bootstrapped SEs)
- Figures: backbone, residuals (3-bin colors), |ΔQ| vs log10(half-life) [if present]
- Density-ratio PNG + a zoomable, panable standalone HTML viewer
- Stable auto-detection if no explicit is_stable column
- summary.json includes counts for stable/overcharged/starved

CSV requirements (minimum): columns A (int), Z (int)
Optional: is_stable (bool/0-1/text), half_life_s (seconds or text like 'stable', 'inf')
"""

import argparse, json, math
from pathlib import Path

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from scipy import stats

def safe_bool_col(s: pd.Series):
    """Map booleans/0-1/yes/no strings to bools; unknown -> NaN."""
    if s is None:
        return None
    if s.dtype == bool:
        return s
    return s.astype(str).str.strip().str.lower().map({
        '1': True, 'true': True, 't': True, 'yes': True, 'y': True,
        '0': False,'false': False,'f': False,'no': False,'n': False
    })

def infer_stable(df: pd.DataFrame, preferred_col: str = None, half_life_raw_col: str = None) -> pd.Series:
    """
    Infer stable isotopes robustly:
    1) If preferred_col exists: map via safe_bool_col and also accept string tokens like 'stable'.
    2) Else scan for any column with 'stable'/'stability' in its name and map similarly.
    3) Else, if a half-life raw text column exists: mark rows with tokens ('stable','inf','infinite')
       OR numeric >= 1e20 seconds (~3e12 years) as stable.
    Returns a boolean Series aligned to df.index (False where unknown).
    """
    stable = None

    # 1) Use preferred column if present
    if preferred_col and preferred_col in df.columns:
        s = df[preferred_col]
        m = safe_bool_col(s)
        # augment with text tokens
        txt = s.astype(str).str.strip().str.lower()
        tok = txt.isin(['stable', 's', 'yes', 'y', 'true', '1'])
        m = m.fillna(False) | tok
        stable = m

    # 2) Scan for likely columns
    if stable is None or stable.sum() == 0:
        cand = [c for c in df.columns if ('stable' in c.lower()) or ('stability' in c.lower())]
        for c in cand:
            s = df[c]
            m = safe_bool_col(s).fillna(False)
            txt = s.astype(str).str.strip().str.lower()
            tok = txt.isin(['stable', 's', 'yes', 'y', 'true', '1'])
            m = m | tok
            if m.sum() > 0:
                stable = m if stable is None else (stable | m)

    # 3) Half-life heuristics
    if (stable is None or stable.sum() == 0) and (half_life_raw_col in df.columns):
        raw = df[half_life_raw_col]
        sval = raw.astype(str).str.strip().str.lower()
        m_text = sval.str.contains('stable') | sval.str.contains('infinite') | sval.eq('inf')
        hn = pd.to_numeric(raw, errors='coerce')
        m_num = hn >= 1e20  # ~3e12 years
        stable = (m_text.fillna(False) | m_num.fillna(False))

    if stable is None:
        stable = pd.Series(False, index=df.index)

    return stable

def fit_core_compression(A: np.ndarray, Z: np.ndarray):
    """OLS fit for Z ≈ c1*A^(2/3) + c2*A; returns dict with metrics and arrays."""
    X = np.column_stack([np.power(A, 2/3), A])
    coef, _, _, _ = np.linalg.lstsq(X, Z, rcond=None)
    c1, c2 = coef
    Zhat = X @ coef
    resid = Z - Zhat
    ss_res = np.sum(resid**2)
    ss_tot = np.sum((Z - np.mean(Z))**2)
    R2 = 1.0 - ss_res/ss_tot
    RMSE = math.sqrt(ss_res / len(Z))

    # Bootstrap SEs
    rng = np.random.default_rng(42)
    B = 1000; n = len(Z); boot = []
    for _ in range(B):
        idx = rng.integers(0, n, size=n)
        Xb, Zb = X[idx], Z[idx]
        cb, *_ = np.linalg.lstsq(Xb, Zb, rcond=None)
        boot.append(cb)
    boot = np.array(boot)
    se_c1, se_c2 = boot.std(axis=0, ddof=1)

    return dict(c1=float(c1), c2=float(c2), se_c1=float(se_c1), se_c2=float(se_c2),
                Zhat=Zhat, resid=resid, R2=float(R2), RMSE=float(RMSE))

def write_interactive_html(path: Path, Agrid: np.ndarray, ratio: np.ndarray, title: str = "Density Impact Ratio — zoom/pan"):
    """Write a standalone HTML (no external deps) with canvas-based pan/zoom line plot."""
    data_js = json.dumps({"A": Agrid.tolist(), "R": ratio.tolist()})
    tmpl = """<!DOCTYPE html>
<html lang="en"><meta charset="utf-8"/>
<title>__TITLE__</title>
<style>
  html,body{height:100%;margin:0;background:#0b0d12;color:#e6eef6;font-family:Inter,system-ui,Segoe UI,Roboto,Helvetica,Arial,sans-serif}
  .wrap{height:100%;display:flex;flex-direction:column}
  header{padding:10px 14px;border-bottom:1px solid #263142}
  header h1{font-size:16px;margin:0}
  #cwrap{flex:1;position:relative}
  canvas{position:absolute;inset:0}
  .hint{position:absolute;left:12px;bottom:10px;opacity:.7;font-size:12px}
</style>
<div class="wrap">
  <header><h1>__TITLE__</h1></header>
  <div id="cwrap"><canvas id="cnv"></canvas><div class="hint">drag to pan • wheel to zoom • double-click to reset</div></div>
</div>
<script>
const DATA = __DATA__;
const canvas = document.getElementById('cnv'); const ctx = canvas.getContext('2d');
function resize(){canvas.width=canvas.clientWidth; canvas.height=canvas.clientHeight; draw();}
window.addEventListener('resize', resize);
const xmin=Math.min(...DATA.A), xmax=Math.max(...DATA.A);
const ymin=0, ymax=Math.max(...DATA.R)*1.05;
let view={x0:xmin, x1:xmax, y0:ymin, y1:ymax}, def={...view};
function x2u(x){return (x-view.x0)/(view.x1-view.x0)*canvas.width;}
function y2v(y){return canvas.height-(y-view.y0)/(view.y1-view.y0)*canvas.height;}
function u2x(u){return view.x0+(u/canvas.width)*(view.x1-view.x0);}
function v2y(v){return view.y0+((canvas.height-v)/canvas.height)*(view.y1-view.y0);}
function drawAxes(){
  ctx.lineWidth=1; ctx.strokeStyle='#3a4860'; ctx.fillStyle='#8fa6be';
  const nx=8, ny=6;
  for(let i=0;i<=nx;i++){const x=view.x0+i*(view.x1-view.x0)/nx, u=x2u(x);
    ctx.beginPath(); ctx.moveTo(u,0); ctx.lineTo(u,canvas.height); ctx.stroke(); ctx.fillText(x.toFixed(0), u+4, canvas.height-6);}
  for(let j=0;j<=ny;j++){const y=view.y0+j*(view.y1-view.y0)/ny, v=y2v(y);
    ctx.beginPath(); ctx.moveTo(0,v); ctx.lineTo(canvas.width,v); ctx.stroke(); ctx.fillText(y.toFixed(2), 6, v-4);}
  ctx.fillText("A (mass number)", canvas.width/2-40, canvas.height-20);
  ctx.save(); ctx.translate(14, canvas.height/2+40); ctx.rotate(-Math.PI/2); ctx.fillText("Density Impact Ratio  (3c2/2c1)·A^{1/3}", 0,0); ctx.restore();
}
function drawCurve(){
  ctx.lineWidth=2; ctx.strokeStyle='#cfd8e3'; ctx.beginPath();
  for(let i=0;i<DATA.A.length;i++){const u=x2u(DATA.A[i]), v=y2v(DATA.R[i]); if(i===0) ctx.moveTo(u,v); else ctx.lineTo(u,v);}
  ctx.stroke();
}
function draw(){ctx.clearRect(0,0,canvas.width,canvas.height); drawAxes(); drawCurve();}
let dragging=false, last=null;
canvas.addEventListener('mousedown', e=>{dragging=true; last={x:e.offsetX,y:e.offsetY};});
window.addEventListener('mouseup', ()=>dragging=false);
window.addEventListener('mousemove', e=>{if(!dragging) return; const dx=e.offsetX-last.x, dy=e.offsetY-last.y; last={x:e.offsetX,y:e.offsetY};
  const wx=(view.x1-view.x0)*(dx/canvas.width), wy=(view.y1-view.y0)*(dy/canvas.height);
  view.x0-=wx; view.x1-=wx; view.y0+=wy; view.y1+=wy; draw();});
canvas.addEventListener('wheel', e=>{e.preventDefault(); const s=Math.pow(1.1, e.deltaY>0?1:-1);
  const x=u2x(e.offsetX), y=v2y(e.offsetY);
  const nx0=x+(view.x0-x)*s, nx1=x+(view.x1-x)*s, ny0=y+(view.y0-y)*s, ny1=y+(view.y1-y)*s;
  const eps=1e-9; if(nx1-nx0>eps && ny1-ny0>eps){view.x0=nx0; view.x1=nx1; view.y0=ny0; view.y1=ny1; draw();}} , {passive:false});
canvas.addEventListener('dblclick', ()=>{view={...def}; draw();});
resize();
</script>
</html>
"""
    html = tmpl.replace("__TITLE__", title).replace("__DATA__", data_js)
    Path(path).write_text(html, encoding="utf-8")

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--csv", required=True, help="Path to CSV with A,Z,(optional) is_stable, half_life_s")
    ap.add_argument("--outdir", default="out")
    ap.add_argument("--stable-col", default="is_stable", help="Use this column for stability if present")
    ap.add_argument("--half-life-col", default="half_life_s")
    args = ap.parse_args()

    outdir = Path(args.outdir); outdir.mkdir(parents=True, exist_ok=True)

    df = pd.read_csv(args.csv)
    if 'A' not in df.columns or 'Z' not in df.columns:
        raise SystemExit("CSV must include columns 'A' and 'Z'.")
    # Coerce numeric
    df['A'] = pd.to_numeric(df['A'], errors='coerce').astype('Int64')
    df['Z'] = pd.to_numeric(df['Z'], errors='coerce').astype('Int64')
    df = df.dropna(subset=['A','Z']).copy()
    df['A'] = df['A'].astype(int); df['Z'] = df['Z'].astype(int)

    # Optional columns
    if args.stable_col in df.columns:
        df['is_stable_bool'] = safe_bool_col(df[args.stable_col])
    else:
        df['is_stable_bool'] = np.nan

    if args.half_life_col in df.columns:
        df['_half_life_raw'] = df[args.half_life_col].copy()
        df['half_life_s'] = pd.to_numeric(df[args.half_life_col], errors='coerce')
    else:
        df['_half_life_raw'] = np.nan
        df['half_life_s'] = np.nan

    # Fit
    res_all = fit_core_compression(df['A'].values.astype(float), df['Z'].values.astype(float))
    df['Zhat_all']  = res_all['Zhat']
    df['resid_all'] = res_all['resid']
    df['abs_resid_all'] = np.abs(df['resid_all'])

    # Stable-only (if we have stable rows)
    R2_stable = RMSE_stable = c1s = c2s = se1s = se2s = None
    # infer stable if not present
    stable_mask = (df['is_stable_bool'] == True) if df['is_stable_bool'].notna().any() else infer_stable(df, preferred_col=None, half_life_raw_col='_half_life_raw')
    if bool(stable_mask.sum() > 0):
        res_s = fit_core_compression(df.loc[stable_mask,'A'].values.astype(float), df.loc[stable_mask,'Z'].values.astype(float))
        R2_stable, RMSE_stable = res_s['R2'], res_s['RMSE']
        c1s, c2s, se1s, se2s = res_s['c1'], res_s['c2'], res_s['se_c1'], res_s['se_c2']

    # Figure 1: Backbone
    fig1 = plt.figure(figsize=(7,5)); ax1 = fig1.add_subplot(111)
    ax1.scatter(df['A'], df['Z'], s=5, alpha=0.5)
    Agrid = np.linspace(df['A'].min(), df['A'].max(), 500)
    Zgrid = res_all['c1']*np.power(Agrid, 2/3) + res_all['c2']*Agrid
    ax1.plot(Agrid, Zgrid, linewidth=2)
    ax1.set_xlabel("Mass number A"); ax1.set_ylabel("Charge Z")
    ax1.set_title("All Isotopes with Fitted Backbone  Z ≈ c1·A^{2/3} + c2·A")
    fig1.tight_layout(); fig1_path = outdir/"figure_backbone_Q_vs_A.png"; fig1.savefig(fig1_path, dpi=180)

    # Figure 2: Residuals — 3-bin coloring
    fig2 = plt.figure(figsize=(7,5)); ax2 = fig2.add_subplot(111)
    has_stable = bool(stable_mask.sum() > 0)
    over = df['resid_all'] > 0
    under = df['resid_all'] < 0
    if has_stable:
        # Draw starved and overcharged first
        ax2.scatter(df.loc[under & ~stable_mask, 'A'], df.loc[under & ~stable_mask, 'resid_all'],
                    s=6, alpha=0.35, label="Starved (ΔQ<0)", c="#1f77b4")
        ax2.scatter(df.loc[over & ~stable_mask, 'A'], df.loc[over & ~stable_mask, 'resid_all'],
                    s=6, alpha=0.35, label="Overcharged (ΔQ>0)", c="#d62728")
        # Stable on top
        ax2.scatter(df.loc[stable_mask, 'A'], df.loc[stable_mask, 'resid_all'],
                    s=12, alpha=0.95, label="Stable (ΔQ≈0)", c="#2ca02c", edgecolors="k", linewidths=0.25, zorder=5)
    else:
        ax2.scatter(df.loc[under, 'A'], df.loc[under, 'resid_all'],
                    s=6, alpha=0.35, label="Starved (ΔQ<0)", c="#1f77b4")
        ax2.scatter(df.loc[over, 'A'], df.loc[over, 'resid_all'],
                    s=6, alpha=0.35, label="Overcharged (ΔQ>0)", c="#d62728")
    ax2.axhline(0.0, linewidth=1.2, color="#444444")
    ax2.set_xlabel("Mass number A"); ax2.set_ylabel("Residual ΔQ = Z - Ẑ")
    ax2.set_title("Residuals relative to Backbone — 3-bin separation")
    ax2.legend(frameon=False, loc="upper right", ncol=1, markerscale=1.2)
    fig2.tight_layout(); fig2_path = outdir/"figure_residuals_vs_A.png"; fig2.savefig(fig2_path, dpi=180)

    # Figure 3: |ΔQ| vs log10(half-life)
    pearson = spearman = None; fig3_path = None
    if df['half_life_s'].notna().any():
        mask = (df['half_life_s']>0) & np.isfinite(df['half_life_s']) & np.isfinite(df['abs_resid_all'])
        if mask.any():
            x = df.loc[mask,'abs_resid_all'].values; y = np.log10(df.loc[mask,'half_life_s'].values)
            fig3 = plt.figure(figsize=(7,5)); ax3 = fig3.add_subplot(111)
            ax3.scatter(x, y, s=5, alpha=0.4)
            ax3.set_xlabel("|ΔQ|"); ax3.set_ylabel("log10(half-life [s])")
            ax3.set_title("|ΔQ| vs log10(half-life)")
            fig3.tight_layout(); fig3_path = outdir/"figure_abs_residual_vs_log10_half_life.png"; fig3.savefig(fig3_path, dpi=180)
            pearson = stats.pearsonr(x, y); spearman = stats.spearmanr(x, y)

    # Figure 4: Density Impact Ratio vs A
    k = (3.0*res_all['c2'])/(2.0*res_all['c1'])
    ratio = k*np.cbrt(Agrid)
    fig4 = plt.figure(figsize=(7,5)); ax4 = fig4.add_subplot(111)
    ax4.plot(Agrid, ratio, linewidth=2, label="Ratio(A) = (3c2/2c1)·A^{1/3}")
    ax4.set_xlabel("Mass number A"); ax4.set_ylabel("Density Impact Ratio (Core / Surface)")
    ax4.set_title("Core Compression Law: All Known Nuclides")
    ax4.legend(frameon=False)
    fig4.tight_layout(); fig4_path = outdir/"figure_density_ratio_vs_A.png"; fig4.savefig(fig4_path, dpi=180)

    # Interactive viewer
    write_interactive_html(outdir/"density_ratio_interactive.html", Agrid, ratio)

    # Summary + counts
    summary = dict(
        counts=dict(
            total=int(len(df)),
            stable=int(stable_mask.sum()) if has_stable else 0,
            overcharged=int((df['resid_all']>0).sum()),
            starved=int((df['resid_all']<0).sum())
        ),
        n_total=int(len(df)),
        n_with_halflife=int(df['half_life_s'].notna().sum()),
        c1=res_all['c1'], c2=res_all['c2'], se_c1=res_all['se_c1'], se_c2=res_all['se_c2'],
        R2_all=res_all['R2'], RMSE_all=res_all['RMSE'],
        R2_stable=R2_stable, RMSE_stable=RMSE_stable,
        c1_stable=c1s, c2_stable=c2s, se_c1_stable=se1s, se_c2_stable=se2s,
        pearson_absdQ_log10T=(pearson.statistic, pearson.pvalue) if pearson else None,
        spearman_absdQ_log10T=(spearman.statistic, spearman.pvalue) if spearman else None,
        figures=dict(
            backbone=str(fig1_path.name),
            residuals=str(fig2_path.name),
            absresid_vs_log10T=str(fig3_path.name) if fig3_path else None,
            density_ratio=str(fig4_path.name),
            density_ratio_html="density_ratio_interactive.html"
        )
    )
    with open(outdir/"summary.json", "w") as f:
        json.dump(summary, f, indent=2)

    # Markdown report (paste-ready)
    def fmt_corr(name, tup):
        return f"{name}: n/a" if tup is None else f"{name}: r={tup[0]:.3f}, p={tup[1]:.2e}"

    lines = []
    lines.append("# Nuclide Law Reproduction Report\n")
    lines.append(f"- Total isotopes: {summary['n_total']}")
    lines.append(f"- With half-life: {summary['n_with_halflife']}")
    lines.append("")
    lines.append(f"**Fit on all isotopes**: R²={summary['R2_all']:.3f}, RMSE={summary['RMSE_all']:.3f}")
    lines.append(f"c1 = {summary['c1']:.6f} ± {summary['se_c1']:.6f}")
    lines.append(f"c2 = {summary['c2']:.6f} ± {summary['se_c2']:.6f}")
    if summary['R2_stable'] is not None:
        lines.append("")
        lines.append(f"**Fit on stable only**: R²={summary['R2_stable']:.3f}, RMSE={summary['RMSE_stable']:.3f}")
        lines.append(f"c1_s = {summary['c1_stable']:.6f} ± {summary['se_c1_stable']:.6f}")
        lines.append(f"c2_s = {summary['c2_stable']:.6f} ± {summary['se_c2_stable']:.6f}")
    lines.append("")
    lines.append(fmt_corr("Pearson(|ΔQ|, log10 T1/2)", summary['pearson_absdQ_log10T']))
    lines.append(fmt_corr("Spearman(|ΔQ|, log10 T1/2)", summary['spearman_absdQ_log10T']))
    lines.append("")
    lines.append("## Figures")
    lines.append(f"![Backbone](./{summary['figures']['backbone']})")
    lines.append(f"![Residuals — 3-bin](./{summary['figures']['residuals']})")
    if summary['figures']['absresid_vs_log10T']:
        lines.append(f"![|ΔQ| vs log10 half-life](./{summary['figures']['absresid_vs_log10T']})")
    lines.append(f"![Density Ratio](./{summary['figures']['density_ratio']})")
    lines.append("Interactive HTML (zoom/pan): density_ratio_interactive.html")
    (Path(args.outdir)/"report.md").write_text("\n".join(lines), encoding="utf-8")

    print("Done. Outputs written to:", args.outdir)

if __name__ == "__main__":
    main()
