# QFD CMB Module — Photon–Photon Scattering Projection

**Version:** 0.1.0 · Generated 2025-09-04

This package provides a minimal, production-ready scaffold to compute QFD-based CMB TT/TE/EE spectra using a
**photon–photon (γγ) sin² kernel** in place of Thomson scattering. It includes both **Limber** and **full line‑of‑sight (LOS)**
projectors, parametric ψ‑field power spectra, flexible visibility functions, and publication‑quality plotting utilities.

## Quick Start

```bash
python -m venv .venv && source .venv/bin/activate
pip install -U numpy scipy matplotlib pandas emcee
python run_demo.py --outdir outputs
```

This generates CSVs and monochrome plots for TT/TE/EE using **Planck‑anchored** parameters (ℓ_A≈301, rψ≈147 Mpc, τ≈0.054).

## Modules

- `qfd_cmb/ppsi_models.py` — families of P_ψ(k), including oscillatory modulation with damping.
- `qfd_cmb/visibility.py` — parametric visibility g(η) and helpers to convert (z,η,χ).
- `qfd_cmb/kernels.py` — γγ sin² angular/polarization kernel as a Mueller‑matrix analogue.
- `qfd_cmb/projector.py` — Limber and full LOS projectors; accepts user source functions S_T,S_E.
- `qfd_cmb/figures.py` — clean, black‑and‑white publication plots (TT/TE/EE; signed TE).
- `fit_planck.py` — scaffold for parameter fitting with `emcee` given Planck/BAO CSVs.
- `run_demo.py` — reproduces the "cosmic‑anchored" toy and saves outputs.

## Data

Place Planck binned TT/TE/EE CSVs and any BAO compilation in `data/` (or pass paths on CLI).
Expected CSV columns for C_ℓ: `ell,C_TT,C_TE,C_EE,error_*` (errors optional).

## Notes

- The LOS projector here is **modular**: you can pass any S_T(k,η), S_E(k,η) callable (e.g., from a more detailed ψ‑dynamics model).
- The included γγ kernel follows the **same quadrupole geometry** as Thomson; only the optical‑depth history differs.
- B‑modes are zero at linear order for parity‑even scalar sources; lensing B can be added in a post‑processing step.

© QFD Project. Apache‑2.0 license.
