import numpy as np

def oscillatory_psik(k, A=1.0, ns=0.96, rpsi=147.0, Aosc=0.55, sigma_osc=0.025):
    # Oscillatory P_ψ(k) with tilt and Gaussian-damped cosine modulation.
    # Ensures positivity by squaring the bracket.
    # Parameters in Mpc-based units if k is in 1/Mpc.
    k = np.asarray(k)
    base = (k + 1e-16)**(ns - 1.0)
    osc  = (1.0 + Aosc * np.cos(k * rpsi) * np.exp(-(k * sigma_osc)**2))
    return A * base * osc**2
