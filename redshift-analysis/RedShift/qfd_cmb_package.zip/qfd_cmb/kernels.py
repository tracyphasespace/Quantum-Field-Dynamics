import numpy as np

def sin2_mueller_coeffs(mu):
    # Intensity and polarization weights for a sin^2(theta) kernel.
    # mu = cos(theta).
    w_T = 1.0 - mu**2          # intensity weight
    w_E = (1.0 - mu**2)        # polarization efficiency (schematic)
    return w_T, w_E

def te_correlation_phase(k, rpsi, ell, chi_star, sigma_phase=0.16, phi0=0.0):
    # Scale-dependent TE correlation coefficient ρ_ℓ mimicking sign flips.
    keff = (ell + 0.5)/chi_star if chi_star>0 else k
    rho = np.cos(keff * rpsi + phi0) * np.exp(- (sigma_phase * (ell/200.0))**2)
    return rho
