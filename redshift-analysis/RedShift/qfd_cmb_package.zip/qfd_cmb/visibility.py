import numpy as np

def gaussian_visibility(eta, eta_star, sigma_eta):
    # Return a normalized Gaussian visibility g(η) centered at η_star.
    x = (eta - eta_star)/sigma_eta
    g = np.exp(-0.5*x*x)
    norm = np.sqrt(np.trapz(g**2, eta))
    return g / (norm + 1e-30)

def gaussian_window_chi(chi, chi_star, sigma_chi):
    # Window in comoving distance χ; L2-normalized.
    x = (chi - chi_star)/sigma_chi
    W = np.exp(-0.5*x*x)
    norm = np.sqrt(np.trapz(W**2, chi))
    return W / (norm + 1e-30)
